defmodule EthereumJSONRPC.WithdrawalTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Withdrawal
end
