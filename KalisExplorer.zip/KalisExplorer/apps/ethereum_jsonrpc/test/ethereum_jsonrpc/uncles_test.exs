defmodule EthereumJSONRPC.UnclesTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Uncles
end
