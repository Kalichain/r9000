defmodule EthereumJSONRPC.UncleTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Uncle
end
