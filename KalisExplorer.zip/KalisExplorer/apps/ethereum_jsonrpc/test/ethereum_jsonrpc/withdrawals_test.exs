defmodule EthereumJSONRPC.WithdrawalsTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Withdrawals
end
