{:ok, _} = Application.ensure_all_started(:credo)
