defmodule Indexer.Tracer do
  @moduledoc false

  use Spandex.Tracer, otp_app: :indexer
end
