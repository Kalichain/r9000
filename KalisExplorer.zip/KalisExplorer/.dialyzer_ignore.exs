[
    {"lib/ethereum_jsonrpc/rolling_window.ex", :improper_list_constr, 171},
    {"lib/explorer/smart_contract/solidity/publisher_worker.ex", :pattern_match, 1},
    {"lib/explorer/smart_contract/solidity/publisher_worker.ex", :exact_eq, 8},
    {"lib/explorer/smart_contract/solidity/publisher_worker.ex", :pattern_match, 8},
    {"lib/explorer/smart_contract/vyper/publisher_worker.ex", :pattern_match, 1},
    {"lib/explorer/smart_contract/vyper/publisher_worker.ex", :exact_eq, 8},
    {"lib/explorer/smart_contract/vyper/publisher_worker.ex", :pattern_match, 8},
    {"lib/explorer/smart_contract/stylus/publisher_worker.ex", :pattern_match, 1},
    {"lib/explorer/smart_contract/stylus/publisher_worker.ex", :exact_eq, 14},
    {"lib/explorer/smart_contract/stylus/publisher_worker.ex", :pattern_match, 14},
    ~r/lib\/phoenix\/router.ex/,
    {"lib/explorer/chain/search.ex", :pattern_match, 80},
    {"lib/explorer/chain/search.ex", :pattern_match, 227},
    {"lib/explorer/chain/search.ex", :pattern_match, 322}
]
